<!DOCTYPE html>
<html>
     <head>
          <title>
          </title>
          <link href="CSS/bootstrap.css" rel="stylesheet" type="text/css">
          </link>
     </head>
     <body>
          <div class="Principal">
               <div class="Menu">
                    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
                         <a class="navbar-brand" href="#">
                              <img alt="Imagen rota" src="Imagenes/Logos.png" width="50%"/>
                         </a>
                         <button aria-controls="navbarColor01" aria-expanded="false" aria-label="Toggle navigation" class="navbar-toggler" data-target="#navbarColor01" data-toggle="collapse" type="button">
                              <span class="navbar-toggler-icon">
                              </span>
                         </button>
                         <div class="collapse navbar-collapse" id="navbarColor01">
                              <ul class="navbar-nav mr-auto">
                                   <li class="nav-item active">
                                        <h1>
                                             <a class="nav-link" href="index.php">
                                                  Inicio
                                                  <span class="sr-only">
                                                       (current)
                                                  </span>
                                             </a>
                                        </h1>
                                   </li>
                                   <li class="nav-item">
                                        <h1>
                                             <a class="nav-link" href="FromAbout.php">
                                                  About
                                             </a>
                                        </h1>
                                   </li>
                              </ul>
                         </div>
                    </nav>
               </div>
          </div>
          <div class="Contenido">
               <div class="BarraDeBusqueda">
                    <p style="color: black;">
                         Aqui va el menu
                    </p>
               </div>
      