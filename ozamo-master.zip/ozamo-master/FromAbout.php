<?php
  
  include 'Header.php';

?>
<div class="Inicio Centrar">
     <div class="Centar">
          <h1>
               ProblemRESULT
          </h1>
          <p>
               Somos un equipo dedicado al desarrollo de software, en pleno desarrollo de habilidades, contamos sabemos trabajar en equipo y dar solucion a los problemas, siempre tratando de cumplir con las expectativas
          </p>
          <h5>
               Integrantes
          </h5>
          <ul>
               <li>
                    Garcia Salas Omar Guillermo
               </li>
               <li>
                    Rosales Nuñez Jose Luis
               </li>
               <li>
                    Soto Mendoza Norberto Trinidad
               </li>
               <li>
                    Zamora Moya Oscar
               </li>
          </ul>
     </div>
</div>
<div class="Pie">
     ?
</div>
